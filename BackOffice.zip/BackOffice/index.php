<?php
require 'connection.php';
$php = 'SELECT IdCategoria, Nome FROM tbl_categorie';
$result=$mysqli->query($php);
if($result==false)
{
    echo 'errore nella query';
}
else
{
    echo "<table><tr><th>Id Categoria</th><th>Nome Categoria</th></tr>";
    $row=$result->fetch_array(MYSQLI_ASSOC);
    $id=$row['IdCategoria'];
    $nome=$row['Nome'];
    echo $id." ".$nome;
}