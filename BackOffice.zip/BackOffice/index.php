<?php
require 'connection.php';
$php = 'SELECT * FROM tbl_categorie';
$result=$mysqli->query($php);
if($result==false)
{
    echo 'errore nella query';
}
else
{
    echo "<table>
            <thead>
            <tr>
            <td>Id Categoria</td>
            <td>Nome Categoria</td>
            </thead>
            </tr>
            <tbody>";
    $nrows = mysqli_num_rows($result);
    $i = 0;
    while($i<$nrows)
    {
        $row=$result->fetch_array(MYSQLI_ASSOC); 
        $id=$row['IdCategoria'];
        $nome=$row['Nome'];
        echo "<tr>   
              <td><?php $id; ?></td>
              <td><?php $nome; ?></td>
              </tr>";
        $i = $i + 1;
    }
}