<html>
    <head>
        <meta charset="UTF-8">
        <title></title>
    </head>
    <body>
        <form action="registrazione.php">
            <h2>Form di Registrazione</h2>
            <h4>Inserisci il tuo nome:</h4>
            <input type="text" name="nome">
            <h4>Inserisci il tuo cognome:</h4>
            <input type="text" name="cognome">
            <h4>Inserisci e-mail:</h4>
            <input type="text" name="email">
            <h4>Inserisci Password:</h4>
            <input type="text" name="password">
            <h4>Inserisci il tuo indirizzo:</h4>
            <input type="text" name="indirizzo"><br>
            <br><input type="submit" value="Registrati">
        </form>
        <?php
        @$mysqli = new mysqli('localhost','root','','db_betaconvenzioni');
        if($mysqli->connect_errno)
        {
            echo "Errore di Connessione";
            exit;
        }
        ?>
    </body>
</html>
